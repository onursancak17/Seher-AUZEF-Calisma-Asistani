"""Seher'in AUZEF Çalışma Asistanı — mobile-first PDF reader and question bank."""
from __future__ import annotations
import csv,hashlib,hmac,io,json,os
from pathlib import Path
import fitz
import streamlit as st
from course_catalog import COURSES, COURSE_BY_ID
from quiz_logic import choose_questions, review_attempt, score_attempt
from storage import list_attempts, save_attempt

ROOT=Path(__file__).resolve().parent
st.set_page_config(page_title='Seher’in AUZEF Çalışma Asistanı',page_icon='🌸',layout='centered',initial_sidebar_state='collapsed')

st.markdown('''<style>
.block-container {max-width:900px;padding-top:1.2rem;padding-bottom:4rem;}
h1,h2,h3 {letter-spacing:-0.02em;}
div[data-testid="stButton"] > button {min-height:2.7rem;border-radius:12px;}
.hero {border:1px solid #e1d6d8;background:linear-gradient(130deg,#fff7f3,#f5f1ff);padding:1.1rem 1.35rem;border-radius:18px;margin-bottom:1rem;color:#352e37;}
.hero h1 {margin:0;font-size:1.65rem;line-height:1.22;}
.hero p {margin:.5rem 0 0;opacity:.85;}
.course-count {font-size:.83rem;opacity:.8;}
.topic-tag {display:inline-block;border-radius:24px;padding:.25rem .65rem;background:#edf3fb;color:#254563;font-size:.84rem;margin:.2rem .2rem .3rem 0;}
.soft {padding:.7rem 1rem;border-radius:12px;background:#f4f7fb;color:#25354b;font-size:.92rem;}
@media (max-width: 600px) { .hero h1{font-size:1.35rem;} .block-container{padding-left:.75rem;padding-right:.75rem;} }
</style>''',unsafe_allow_html=True)

@st.cache_data(show_spinner=False)
def load_bank(slug):
    return json.loads((ROOT/'data'/f'{slug}.json').read_text(encoding='utf-8'))

@st.cache_data(show_spinner=False)
def pdf_page(slug,page_num,unit=None,scale=1.7):
    f=get_pdf_path(slug,unit)
    with fitz.open(f) as doc:
        pix=doc[page_num-1].get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False)
        return pix.tobytes('png')

@st.cache_data(show_spinner=False)
def pdf_info(slug,unit=None):
    with fitz.open(get_pdf_path(slug,unit)) as doc:
        return len(doc)

@st.cache_data(show_spinner=False)
def unit_titles():
    return json.loads((ROOT/'data'/'unit_titles.json').read_text(encoding='utf-8'))


def get_pdf_path(slug,unit=None):
    return ROOT/'pdfs'/('units/'+f'{slug}_{unit:02d}.pdf' if unit is not None else COURSE_BY_ID[slug]['pdf'])

@st.cache_data(show_spinner=False)
def all_banks():
    return {c['id']:load_bank(c['id']) for c in COURSES}


def get_secret():
    env=os.environ.get('APP_PASSWORD','')
    if env:
        return env
    try:
        return st.secrets.get('APP_PASSWORD','')
    except (FileNotFoundError,KeyError):
        return ''


def login():
    st.markdown('<div class="hero"><h1>🌸 Seher’in Ders Köşesi</h1><p>7 ders, PDF notları ve açıklamalı soru bankası</p></div>',unsafe_allow_html=True)
    secret=get_secret()
    if not secret:
        st.error('Uygulama erişim şifresi henüz tanımlanmamış. Yönetici, Streamlit Cloud → App settings → Secrets bölümüne APP_PASSWORD eklemeli.')
        st.stop()
    if st.session_state.get('authenticated',False):
        return
    with st.form('login_form'):
        password=st.text_input('Çalışma alanı şifresi',type='password',placeholder='Şifreni gir')
        ok=st.form_submit_button('Giriş yap',use_container_width=True)
    if ok:
        if hmac.compare_digest(password.encode('utf-8'),str(secret).encode('utf-8')):
            st.session_state['authenticated']=True
            st.rerun()
        else:
            st.error('Şifre eşleşmedi. Tekrar deneyebilirsin.')
    st.stop()


def goto(screen,course=None):
    st.session_state['nav']=screen
    if course is not None:
        st.session_state['course']=course


def show_home():
    banks=all_banks()
    total=sum(len(x) for x in banks.values())
    col1,col2,col3=st.columns(3)
    col1.metric('Ders',7)
    col2.metric('Ünite',sum(c['units'] for c in COURSES))
    col3.metric('Soru',f'{total:,}'.replace(',','.'))
    st.markdown('### Ders seç')
    for course in COURSES:
        with st.container(border=True):
            c1,c2=st.columns([5,2],vertical_alignment='center')
            c1.markdown(f"**{course['icon']} {course['name']}**")
            c1.caption(course['description'])
            c1.caption(f"{course['units']} ünite · {len(banks[course['id']])} soru")
            with c2:
                st.button('📖 PDF',key='open_pdf_'+course['id'],use_container_width=True,on_click=goto,args=('📖 Notlar',course['id']))
                st.button('✍️ Test',key='open_test_'+course['id'],use_container_width=True,on_click=goto,args=('✍️ Test',course['id']))
    st.info('Sorular, daha önce hazırladığımız PDF çalışma rehberlerinden alınmıştır. Üniversitenin resmî çıkmış sınav soruları değildir.')


def turn_pdf(course,unit,delta):
    key=f"pdf_page_{course}_{unit}" if unit is not None else f"pdf_page_{course}_full"
    st.session_state[key]=max(1,min(pdf_info(course,unit),st.session_state.get(key,1)+delta))


def show_pdf():
    course=st.session_state['course']
    c=COURSE_BY_ID[course]
    st.subheader(f"{c['icon']} {c['name']}")
    st.caption('Birleşik PDF çalışma notlarını telefonundan sayfa sayfa okuyabilirsin. Üniteye özel testleri Test bölümünden seçebilirsin.')
    n=pdf_info(course)
    key=f'pdf_page_{course}_full'
    if key not in st.session_state: st.session_state[key]=1
    st.slider('PDF sayfası',min_value=1,max_value=n,key=key)
    b1,b2=st.columns(2)
    b1.button('← Önceki sayfa',key=f'prev_pdf_{course}',disabled=st.session_state[key]==1,use_container_width=True,on_click=turn_pdf,args=(course,None,-1))
    b2.button('Sonraki sayfa →',key=f'next_pdf_{course}',disabled=st.session_state[key]>=n,use_container_width=True,on_click=turn_pdf,args=(course,None,1))
    with st.spinner('Sayfa hazırlanıyor...'):
        st.image(pdf_page(course,st.session_state[key]),use_container_width=True)
    with get_pdf_path(course).open('rb') as f:
        st.download_button('📥 Bu PDF’yi indir',data=f,file_name=f'Seher_{course}_tam_rehber.pdf',mime='application/pdf',use_container_width=True)


def start_quiz(course,unit,count,shuffle):
    bank=load_bank(course)
    sel=choose_questions(bank,unit,None if count=='Tümü' else int(count),shuffle=shuffle)
    st.session_state['active_quiz']={
        'course':course,'unit':unit,'ids':[q['id'] for q in sel], 'pos':0,'responses':{},'finished':False,
    }


def save_answer(qid):
    state=st.session_state.get('active_quiz')
    if state:
        val=st.session_state.get(f'_choice_{qid}')
        if val in ('A','B','C','D','E'):state['responses'][qid]=val
        else:state['responses'].pop(qid,None)


def move_quiz(delta):
    quiz=st.session_state['active_quiz']
    quiz['pos']=max(0,min(len(quiz['ids'])-1,quiz['pos']+delta))


def finish_quiz():
    quiz=st.session_state['active_quiz']
    bank={q['id']:q for q in load_bank(quiz['course'])}
    questions=[bank[qid] for qid in quiz['ids']]
    results=score_attempt(questions,quiz['responses'])
    quiz['score']=results
    quiz['finished']=True
    quiz['stored_id']=save_attempt(quiz['course'],quiz['unit'] if quiz['unit'] is not None else 'Hepsi',results,quiz['ids'],quiz['responses'])


def show_review(questions,responses,score,header='Test sonucu'):
    st.subheader(header)
    a,b,c,d=st.columns(4)
    a.metric('Doğru',score['correct'])
    b.metric('Yanlış',score['wrong'])
    c.metric('Boş',score['unanswered'])
    d.metric('Başarı',f"%{score['percent']:g}")
    st.progress(score['correct']/max(len(questions),1),text=f"{score['correct']} / {len(questions)} doğru")
    st.markdown('#### Bütün soruların açıklamaları')
    st.caption('Doğru yaptığın soruların da yanlış yaptıklarının da gerekçesini görebilirsin.')
    for i,r in enumerate(review_attempt(questions,responses),1):
        q=r['question'];sel=r['selected'];status=r['status']
        symbol={'Doğru':'✅','Yanlış':'❌','Boş':'⚪'}[status]
        with st.expander(f"{symbol} Soru {i} — {status}: {q['question'][:82]}",expanded=(status!='Doğru')):
            st.markdown(f"**{q['question']}**")
            for option,text in q['options'].items():
                prefix='✅ ' if option==q['answer'] else ('➜ ' if option==sel else '')
                st.write(f"{prefix}{option}) {text}")
            st.write(f"**Seher'in cevabı:** {sel if sel else 'Boş bırakıldı'}")
            st.write(f"**Doğru cevap:** {q['answer']}) {q['options'][q['answer']]}")
            st.info(f"**Neden?** {q['explanation']}")


def show_quiz():
    course=st.session_state['course']
    c=COURSE_BY_ID[course]
    st.subheader(f"✍️ {c['name']} — Test")
    q=st.session_state.get('active_quiz')
    if q and q.get('finished'):
        if q['course']!=course:
            st.warning('Bitmiş başka bir ders testin bulunuyor. Yeni test başlatabilirsin.')
        else:
            bank={x['id']:x for x in load_bank(course)}
            show_review([bank[k] for k in q['ids']],q['responses'],q['score'])
            if st.button('Yeni test başlat',use_container_width=True,type='primary'):
                st.session_state.pop('active_quiz',None)
                st.rerun()
            return
    if not q or q['course']!=course:
        with st.container(border=True):
            st.markdown('#### Yeni test ayarla')
            unit_choice=st.selectbox('Ünite',options=[None]+list(range(1,c['units']+1)),format_func=lambda x:'Tüm üniteler (karma)' if x is None else f"{x}. Ünite — {unit_titles()[course][str(x)]}",key='pick_unit_'+course)
            total_for_unit=len([x for x in load_bank(course) if unit_choice is None or x['unit']==unit_choice])
            counts=[v for v in [10,15,20,30,50] if v<total_for_unit]+['Tümü']
            count=st.selectbox('Kaç soru çözmek istersin?',counts,index=0)
            shuffle=st.checkbox('Soruları karıştır',value=unit_choice is None)
            st.caption(f'Bu seçimde {total_for_unit} soru bulunuyor.')
            if st.button('Teste başla',type='primary',use_container_width=True):
                start_quiz(course,unit_choice,count,shuffle)
                st.rerun()
        return
    bank={x['id']:x for x in load_bank(course)}
    questions=[bank[k] for k in q['ids']]
    idx=q['pos'];current=questions[idx]
    done=sum(1 for k in q['ids'] if q['responses'].get(k) in ('A','B','C','D','E'))
    st.caption(f"Soru {idx+1} / {len(questions)} • {done} cevap işaretlendi")
    st.progress(done/max(len(questions),1))
    with st.container(border=True):
        st.markdown(f"**{idx+1}. {current['question']}**")
        prev_answer=q['responses'].get(current['id'])
        radio_key=f"_choice_{current['id']}"
        # State is copied to durable attempt dictionary before navigating; widgets may unmount.
        st.radio('Yanıtını seç',options=list('ABCDE'),format_func=lambda key:f"{key}) {current['options'][key]}",index=list('ABCDE').index(prev_answer) if prev_answer in ('A','B','C','D','E') else None,key=radio_key,on_change=save_answer,args=(current['id'],))
    a,b=st.columns(2)
    a.button('← Önceki',key='prev_question',disabled=idx==0,use_container_width=True,on_click=move_quiz,args=(-1,))
    b.button('Sonraki →',key='next_question',disabled=idx==len(questions)-1,use_container_width=True,on_click=move_quiz,args=(1,))
    st.button('✅ Testi bitir ve sonuçları gör',type='primary',use_container_width=True,on_click=finish_quiz)
    st.caption('Testi bitirmeden doğru cevaplar gösterilmez. Boş sorular sonuç ekranında ayrıca sayılır.')
    with st.expander('Testi iptal et'):
        st.warning('İptal ettiğinde bu testteki işaretlemeler kaybolur; sonuç kaydedilmez.')
        if st.button('Testi iptal et ve yeni başlat',key='cancel_quiz',use_container_width=True):
            st.session_state.pop('active_quiz',None)
            st.rerun()


def history_csv(rows):
    buf=io.StringIO()
    writer=csv.writer(buf)
    writer.writerow(['Tarih','Ders','Ünite','Toplam','Doğru','Yanlış','Boş','Başarı %'])
    for a in rows:
        writer.writerow([a['timestamp'],COURSE_BY_ID.get(a['course'],{}).get('name',a['course']),a['unit'],a['total'],a['correct'],a['wrong'],a['unanswered'],a['percent']])
    return buf.getvalue().encode('utf-8-sig')


def show_history():
    st.subheader('📈 Sonuçlarım')
    attempts=list_attempts()
    if not attempts:
        st.info('Henüz bitirilmiş test yok. İlk testini bitirdiğinde sonuçlarını burada göreceksin.')
        return
    scores=[r['percent'] for r in attempts]
    a,b=st.columns(2)
    a.metric('Tamamlanan test',len(attempts))
    b.metric('Ortalama başarı',f"%{sum(scores)/len(scores):.1f}")
    for a in attempts[:20]:
        c=COURSE_BY_ID.get(a['course'],{})
        with st.container(border=True):
            st.markdown(f"**{c.get('icon','📘')} {c.get('name',a['course'])}**")
            st.caption(f"{a['timestamp']} · {a['unit']}. ünite" if str(a['unit']).isdigit() else f"{a['timestamp']} · Karma")
            st.write(f"✅ {a['correct']} doğru · ❌ {a['wrong']} yanlış · ⚪ {a['unanswered']} boş · **%{a['percent']:g}**")
            with st.expander('Bu testin soru ve cevaplarını gör'):
                bank={q['id']:q for q in load_bank(a['course'])}
                questions=[bank[k] for k in a['question_ids'] if k in bank]
                show_review(questions,a['responses'],score_attempt(questions,a['responses']),header='Açıklamalı sonuç')
    st.download_button('📥 Sonuçları CSV olarak indir',data=history_csv(attempts),file_name='seher_sinav_sonuclari.csv',mime='text/csv',use_container_width=True)
    st.caption('Önemli: Streamlit Community Cloud yeniden başlatıldığında yerel sonuç veritabanı silinebilir. CSV yedeğini saklamanı öneririm.')


def main():
    login()
    st.markdown('<div class="hero"><h1>🌸 Seher’in AUZEF Çalışma Asistanı</h1><p>Kendi notlarını oku, öğrendiklerini sorularla pekiştir.</p></div>',unsafe_allow_html=True)
    cols=st.columns([6,1],vertical_alignment='center')
    with cols[1]:
        if st.button('Çıkış',key='logout',help='Oturumu kapat'):
            st.session_state.clear();st.rerun()
    if 'nav' not in st.session_state:st.session_state['nav']='📚 Dersler'
    if 'course' not in st.session_state:st.session_state['course']='anatomi'
    nav=st.segmented_control('Bölüm',options=['📚 Dersler','📖 Notlar','✍️ Test','📈 Sonuçlar'],key='nav',label_visibility='collapsed')
    if nav!='📚 Dersler':
        ids=[c['id'] for c in COURSES]
        st.selectbox('Ders',ids,format_func=lambda slug:f"{COURSE_BY_ID[slug]['icon']} {COURSE_BY_ID[slug]['name']}",key='course')
    if nav=='📚 Dersler':show_home()
    elif nav=='📖 Notlar':show_pdf()
    elif nav=='✍️ Test':show_quiz()
    else:show_history()
    st.divider()
    st.caption('Yalnızca AUZEF ders kitabından oluşturulan önceki çalışma notları kullanılmıştır. Resmî sınav uygulaması değildir.')

if __name__=='__main__':main()
