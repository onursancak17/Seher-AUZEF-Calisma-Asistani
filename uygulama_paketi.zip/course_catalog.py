"""Seven source-bound AUZEF study sets."""
COURSES = [
    {'id':'anatomi','name':'Anatomi','icon':'🫀','units':8,'pdf':'anatomi.pdf','accent':'#BE5A61','description':'Vücut sistemleri ve anatomik terimler'},
    {'id':'bilimsel','name':'Bilimsel Araştırma Teknikleri','icon':'🔬','units':8,'pdf':'bilimsel.pdf','accent':'#557E8A','description':'Bilimsel süreç ve araştırma yöntemleri'},
    {'id':'sosyoloji','name':'Sosyolojiye Giriş','icon':'🌍','units':14,'pdf':'sosyoloji.pdf','accent':'#8869AD','description':'Toplum, kültür ve toplumsal kurumlar'},
    {'id':'psikoloji','name':'Psikoloji','icon':'🧠','units':12,'pdf':'psikoloji.pdf','accent':'#B27A42','description':'Davranış, öğrenme, gelişim ve algı'},
    {'id':'ingilizce','name':'Yabancı Dil I (İngilizce)','icon':'🇬🇧','units':14,'pdf':'ingilizce.pdf','accent':'#416FAB','description':'Dil bilgisi, kelimeler ve alıştırmalar'},
    {'id':'turk_dili','name':'Türk Dili I','icon':'✍️','units':14,'pdf':'turk_dili.pdf','accent':'#4C927B','description':'Dil bilgisi, tarih ve anlatım'},
    {'id':'ataturk','name':'Atatürk İlkeleri ve İnkılap Tarihi I','icon':'🇹🇷','units':14,'pdf':'ataturk.pdf','accent':'#B85B4C','description':'Osmanlı modernleşmesi ve Millî Mücadele'},
]
COURSE_BY_ID={c['id']:c for c in COURSES}
