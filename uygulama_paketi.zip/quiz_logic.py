"""Pure functions for Seher's AUZEF self-study quizzes."""
from __future__ import annotations
import random


def choose_questions(bank: list[dict], unit: int | None, count: int | None, shuffle: bool = False, seed: int | None = None) -> list[dict]:
    choices = [q for q in bank if unit is None or q['unit'] == unit]
    if shuffle:
        choices = choices.copy()
        random.Random(seed).shuffle(choices)
    if count is not None:
        choices = choices[:min(count, len(choices))]
    return choices


def score_attempt(questions: list[dict], answers: dict[str, str]) -> dict:
    correct = sum(answers.get(q['id']) == q['answer'] for q in questions)
    unanswered = sum(answers.get(q['id']) not in ('A', 'B', 'C', 'D', 'E') for q in questions)
    wrong = len(questions) - correct - unanswered
    total = len(questions)
    return {
        'correct': correct,
        'wrong': wrong,
        'unanswered': unanswered,
        'total': total,
        'percent': round(100 * correct / total, 1) if total else 0,
        'answered': total - unanswered,
    }


def review_attempt(questions: list[dict], answers: dict[str, str]) -> list[dict]:
    results = []
    for q in questions:
        selected = answers.get(q['id'])
        status = 'Boş' if selected not in ('A', 'B', 'C', 'D', 'E') else ('Doğru' if selected == q['answer'] else 'Yanlış')
        results.append({'question':q, 'selected':selected, 'status':status})
    return results
