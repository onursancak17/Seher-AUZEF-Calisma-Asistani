"""Local SQLite attempt history. Persistent on local PC; ephemeral on some cloud hosts."""
from __future__ import annotations
import json,sqlite3,uuid,os
from datetime import datetime,timezone
from pathlib import Path

DB=Path(os.getenv('SEHER_PROGRESS_DB',str(Path(__file__).parent/'.local'/'seher_results.sqlite')))


def connect():
    DB.parent.mkdir(parents=True,exist_ok=True)
    conn=sqlite3.connect(DB,timeout=15)
    conn.execute('''CREATE TABLE IF NOT EXISTS attempts (
        id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        course TEXT NOT NULL,
        unit TEXT NOT NULL,
        total INTEGER NOT NULL,
        correct INTEGER NOT NULL,
        wrong INTEGER NOT NULL,
        unanswered INTEGER NOT NULL,
        percent REAL NOT NULL,
        question_ids_json TEXT NOT NULL,
        responses_json TEXT NOT NULL
    )''')
    return conn


def save_attempt(course, unit, score, question_ids, responses):
    aid=str(uuid.uuid4())
    time=datetime.now(timezone.utc).astimezone().isoformat(timespec='minutes')
    with connect() as conn:
        conn.execute('INSERT INTO attempts VALUES (?,?,?,?,?,?,?,?,?,?,?)',(
            aid,time,course,str(unit),score['total'],score['correct'],score['wrong'],score['unanswered'],
            score['percent'],json.dumps(question_ids,ensure_ascii=False),json.dumps(responses,ensure_ascii=False)))
    return aid


def list_attempts(limit=300):
    with connect() as conn:
        conn.row_factory=sqlite3.Row
        rows=conn.execute('SELECT * FROM attempts ORDER BY timestamp DESC LIMIT ?',(limit,)).fetchall()
    records=[]
    for r in rows:
        d=dict(r)
        d['question_ids']=json.loads(d.pop('question_ids_json'))
        d['responses']=json.loads(d.pop('responses_json'))
        records.append(d)
    return records
