"""Extract *existing* question + explained answer from user's AUZEF notes; never generate answers."""
from __future__ import annotations
import fitz,json,re,sys,collections,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
DATA=ROOT/'data'
SOURCE=ROOT/'pdfs'/'units'
COURSES=[
 ('anatomi','Anatomi','anatomi_{:02d}.pdf',8),
 ('bilimsel','Bilimsel Araştırma Teknikleri','bilimsel_{:02d}.pdf',8),
 ('sosyoloji','Sosyolojiye Giriş','sosyoloji_{:02d}.pdf',14),
 ('psikoloji','Psikoloji','psikoloji_{:02d}.pdf',12),
 ('ingilizce','Yabancı Dil I (İngilizce)','ingilizce_{:02d}.pdf',14),
 ('turk_dili','Türk Dili I','turk_dili_{:02d}.pdf',14),
 ('ataturk','Atatürk İlkeleri ve İnkılap Tarihi I','ataturk_{:02d}.pdf',14),
]
COURSE_META={}
QNUM=re.compile(r'(?m)^\s*(\d{1,2}(?:\.\d{2})?)[.)]\s+(?=[^\n])')
OPT=re.compile(r'(?<!\w)([A-E])\)\s*')
ANS=re.compile(r'(?m)^\s*(\d{1,2}(?:\.\d{2})?)\s*[.)]?\s*[—–-]?\s*([A-E])(?=\s*(?:[—–-]|\bDoğru yanıt\s*:|\|))\s*(?:[—–-]|Doğru yanıt\s*:|\|)?\s*')
HEADING_ANSWER=re.compile(r'(?im)^\s*(?:(?:\d{1,2})[.]\s*ÜNİTE\s*[|/]\s*|(?:\d{1,2})\s*[.\|]\s*)?AÇIKLAMALI CEVAP ANAHTARI\s*$')
HEADINGS_Q=[re.compile(s,re.I|re.M) for s in [
 r'^\s*(?:\d{1,2}\s*[.\|]\s*)?\d{1,3}\s+ÖZGÜN ÇOKTAN SEÇMELİ SORU',
 r'^\s*(?:\d{1,2}\s*[.\|]\s*)?\d{1,3}\s+ÖZGÜN (?:TEST|SORU)',
 r'^\s*(?:\d{1,2}\s*[.\|]\s*)?\d{1,3}\s+ÖZGÜN BEŞ SEÇENEKLİ TEST',
 r'^\s*\d{1,2}[.\|]\s*(?:ÖZGÜN )?TEST SORULARI',
 r'^\s*\d{1,2}[.\|]\s*\d{1,3}\s+SORULUK (?:ALIŞTIRMA|ÜNİTE) TESTİ',
 r'^\s*\d{1,2}[.\|]\s*ÜNİTE\s*[|/]\s*(?:ÖZGÜN )?TEST SORULARI',
 r'^\s*\d{1,2}[.\|]\s*ÜNİTE\s*[|/]\s*\d{1,3}\s+SORULUK ALIŞTIRMA TESTİ',
 r'^\s*\d{1,2}\s*\|\s*ÇOKTAN SEÇMELİ ÜNİTE TESTİ',
 r'^\s*ÜNİTE SONU\s*[-–]\s*10 KAYNAK TEST SORUSU',
 r'^\s*\d{1,3}\s+ÖZGÜN ÇOKTAN SEÇMELİ SORU',
 r'^\s*\d{1,2}\s*\|\s*TEST SORULARI',
 r'^\s*\d{1,2}\s*\|\s*(?:ÖZGÜN )?SORULAR',
 r'^\s*\d{1,3}\s+SORULUK ALIŞTIRMA TESTİ',
 r'^\s*\d{1,3}\s+ÖZGÜN SORU',
 r'^\s*(?:\d{1,2}\s*[.|]\s*)?\d{1,3}\s+SORULUK ÜNİTE TESTİ',
 r'^\s*(?:\d{1,2}\s*[.|]\s*)?ÇOKTAN SEÇMELİ ÜNİTE TESTİ',
 r'^\s*(?:\d{1,2}\s*[.|]\s*)?\d{1,3}\s+SORULUK ALIŞTIRMA TESTİ'
]]

def clean(s):
 s=re.sub(r'(?i)Kaynak:\s*ANATOMİ\.pdf,\s*s\.\s*88\s*[-–]\s*99\s*\|\s*Eğitim amaçlı özgün rehber\s*\d+','',s)
 s=re.sub(r'(?i)Yalnızca yüklenen AUZEF Psikoloji kitabından hazırlanmıştır\.?\s*\d*','',s)
 s=re.sub(r'(?i)AUZEF\s*\|\s*A\s*t\s*i\s*7\s*Ü\s*it\s*\|[^\n]*','',s)
 return re.sub(r'\s+',' ',s).strip(' \n\t-•')

def page_text(page):
 # Exclude repeating top/bottom page decorations, keep test headings.
 return page.get_text(sort=True,clip=fitz.Rect(0,47,page.rect.width,page.rect.height-37))

def segment(doc,slug,unit):
 state='pre';qs=[];ans=[]
 for index,page in enumerate(doc):
  t=page_text(page)
  ma=HEADING_ANSWER.search(t)
  matches=[m for pat in HEADINGS_Q for m in pat.finditer(t)]
  if state=='pre':
   if matches and (not ma or min(m.start() for m in matches)<ma.start()):
    qstart=min(m.end() for m in matches)
    state='qs'
    if ma:
     qs.append(t[qstart:ma.start()]);ans.append(t[ma.end():]);state='ans'
    else:qs.append(t[qstart:])
   else:
    # Detect first question page even if no exact heading; only with 5 options + ?
    opts=len(OPT.findall(t)); candidate=QNUM.search(t)
    if opts>=5 and candidate and not ma:
     text=t[candidate.start():]
     if len(OPT.findall(text))>=5:
      qs.append(text);state='qs'
  elif state=='qs':
   if ma:
    qs.append(t[:ma.start()]);ans.append(t[ma.end():]);state='ans'
   else:qs.append(t)
  else:ans.append(t)
 return '\n'.join(qs), '\n'.join(ans),state

def parse_questions(text):
 result={}
 matches=list(QNUM.finditer(text))
 for k,m in enumerate(matches):
  num=m.group(1); num=str(int(num)) if '.' not in num else num; segment=text[m.end():matches[k+1].start() if k+1<len(matches) else len(text)]
  options=list(OPT.finditer(segment))
  if len(options)!=5 or [o.group(1) for o in options]!=list('ABCDE'):
   continue
  title=clean(segment[:options[0].start()])
  vals=[clean(segment[o.end():options[j+1].start() if j+1<5 else len(segment)]) for j,o in enumerate(options)]
  if not title or min(len(v) for v in vals)<1:continue
  result[num]=(title,dict(zip('ABCDE',vals)))
 return result

def parse_answers(text):
 result={}
 matches=list(ANS.finditer(text))
 for i,m in enumerate(matches):
  num,answer=m.group(1),m.group(2);num=str(int(num)) if '.' not in num else num
  raw=text[m.end():matches[i+1].start() if i+1<len(matches) else len(text)]
  # Last answer on each unit page may be followed by unrelated revision notes.
  stop=r'(?im)(?:^\s*(?:\d+\s*[|.]\s*)?(?:SON TEKRAR(?:\s*\|[^\n]*)?|SON TEKRAR KONTROLÜ|ÜNİTE SONU KONTROL|ÜNİTEYİ BİTİRME KONTROLÜ|SINAV ÖNCESİ HIZLI TEKRAR|SON GÜN(?: 5 DAKİKALIK)? TEKRAR(?: FİŞİ)?|Kaynak eşleştirme ve kontrol listesi|Kitap ünite sonu sorularıyla konu eşleştirmesi|Kaynak-kapsam kontrol listesi|Son gün için 25 saniyelik tekrar kartları|KAYNAK DENETİMİ|KAPSAM DENETİMİ|İlk ünite için kaynakla kapsam kontrolü|Kaynakla kapsam kontrolü|Ünite sonu kontrol listesi|KAYNAK SINIRI|KONU ÖZETİ|HIZLI TEKRAR FİŞİ|ÜNİTE ÖZETİ)\b|Kaynak sınırı:)'
  raw=re.split(stop,raw,maxsplit=1)[0]
  content=clean(raw)
  content=re.sub(r'(?i)^(?:doğru\s+yanıt\s*:)\s*','',content)
  # no marker may mean explanation missing; don't invent
  if content:result[num]=(answer,content)
 return result

def find_units():
 out=[]; report=[]
 for slug,name,pattern,n in COURSES:
  records=[]
  for unit in range(1,n+1):
   f=SOURCE/pattern.format(unit)
   if not f.exists():report.append((slug,unit,'MISSING PDF'));continue
   d=fitz.open(f); qtext,atext,state=segment(d,slug,unit)
   questions=parse_questions(qtext);answers=parse_answers(atext)
   missing=[q for q in questions if q not in answers]
   extra=[q for q in answers if q not in questions]
   complete={}
   for num,(title,choices) in questions.items():
    if num in answers:
     correct,exp=answers[num]
     complete[num]={'id':f'{slug}_{unit:02d}_{num.replace(".","_")}','unit':unit,'number':num,'question':title,'options':choices,'answer':correct,'explanation':exp,'source_pdf':f.name}
   records.extend(complete.values())
   report.append((slug,unit,len(d),state,len(questions),len(answers),len(complete),len(missing),len(extra),str(list(questions.items())[:1])[:120]))
  target=DATA/f'{slug}.json'
  target.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
  print('COURSE',slug,'records',len(records),flush=True)
  out.append((slug,records))
 (DATA/'_extraction_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 for row in report:print(*row[:9],sep=' | ')
 return out

if __name__=='__main__':find_units()
