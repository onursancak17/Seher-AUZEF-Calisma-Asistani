import unittest, pathlib, sys, json
BASE=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
from course_catalog import COURSES
from quiz_logic import choose_questions, score_attempt, review_attempt
from storage import list_attempts, save_attempt

class QuizTest(unittest.TestCase):
    def test_all_seven_course_banks(self):
        counts={'anatomi':437,'bilimsel':96,'sosyoloji':244,'psikoloji':120,'ingilizce':210,'turk_dili':234,'ataturk':170}
        for c in COURSES:
            key=c['id']; questions=json.loads((BASE/'data'/f'{key}.json').read_text(encoding='utf-8'))
            self.assertEqual(len(questions),counts[key],key)
            self.assertEqual(len({q['id'] for q in questions}),counts[key],key)
            self.assertEqual({q['unit'] for q in questions},set(range(1,c['units']+1)),key)
            for q in questions:
                self.assertEqual(list(q['options']),list('ABCDE'))
                self.assertIn(q['answer'],'ABCDE')
                self.assertTrue(q['question'])
                self.assertTrue(q['explanation'])
                self.assertTrue(all(q['options'].values()))

    def test_scoring_and_review(self):
        sample=[{'id':'a','answer':'B','unit':1},{'id':'b','answer':'C','unit':1},{'id':'c','answer':'A','unit':2}]
        answers={'a':'B','b':'D'}
        got=score_attempt(sample,answers)
        self.assertEqual((got['correct'],got['wrong'],got['unanswered'],got['percent']),(1,1,1,33.3))
        self.assertEqual([q['status'] for q in review_attempt(sample,answers)],['Doğru','Yanlış','Boş'])
        self.assertEqual(len(choose_questions(sample,unit=1,count=10)),2)

if __name__=='__main__':unittest.main()
